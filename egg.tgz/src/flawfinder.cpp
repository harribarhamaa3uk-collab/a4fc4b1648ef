// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("flawfinder"); }
int main(){
  announce();
  return lionss_run_workload("flawfinder");
}
