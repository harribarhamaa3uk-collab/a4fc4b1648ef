// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("pkg config check"); }
int main(){
  announce();
  return lionss_run_workload("pkg-config-check");
}
