// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("bisect regression\n", stdout);
  return lionss_run_workload("bisect-regression");
}
