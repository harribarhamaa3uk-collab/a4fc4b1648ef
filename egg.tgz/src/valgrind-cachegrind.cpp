// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("valgrind cachegrind"); }
int main(){
  announce();
  return lionss_run_workload("valgrind-cachegrind");
}
